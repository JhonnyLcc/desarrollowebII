# Idea Capture Form
Used the following technologies to buils the HTML 5, CSS, JQuery and Ajax
