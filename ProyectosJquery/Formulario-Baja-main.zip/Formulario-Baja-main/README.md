# Formulario-Baja
Formulario para llenar un registro de baja construido con HTML, CSS, Boostrap, y Jquery. 
